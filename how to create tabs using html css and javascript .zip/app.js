var button = document.querySelectorAll('button');
var tab = document.querySelectorAll('.tab');

function active(i, c) {
    button.forEach(function(node) {
        node.style.backgroundColor = "black";
        node.style.color = "white";
    });
    button[i].style.backgroundColor = c;
    tab.forEach(function(node) {
        node.style.display = "none";
    })
    tab[i].style.display = "block";
}
active(0, "black");